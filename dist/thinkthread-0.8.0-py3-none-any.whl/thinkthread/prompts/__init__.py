"""Prompt templates for the ThinkThread SDK.

This package contains Jinja2 templates for prompts used in the
Chain-of-Recursive-Thoughts reasoning process.
"""
