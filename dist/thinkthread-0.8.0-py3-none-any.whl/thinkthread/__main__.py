"""Command-line entry point for the ThinkThread SDK."""

from thinkthread.cli import app

if __name__ == "__main__":
    app()
